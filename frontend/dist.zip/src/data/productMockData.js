/**
 * 产品配置 mock 数据与表单 schema 生成器
 * 移植自 prodai-cfg-demo/src/data/mockData.js，适配 DynamicForm schema 结构
 */

export const mockProducts = [
  {
    id: 'P001',
    code: 'WO20250115001',
    name: '动感地带青春卡99元G',
    template: 'personMainPrc',
    desc: '月费99元 | 20G流量 | 500分钟语音 | 合约24个月',
    status: 'submitted',
    auditStatus: 'pass',
    data: {
      workOrderId: 'WO20250115001',
      prodPrcName: '动感地带青春卡99元G',
      effRuleId: '1001',
      expRuleId: '1023',
      effDate: '2026-07-01',
      expDate: '2099-12-31',
      prodId: 'APAP00001',
      prodPrcId: 'ACAG00001',
      chnClassLimit: 'A7',
      groupId: '10001',
      groupIdMessage: '1,2,3',
      prcMonthFee: '99元/月',
      containResource: '20G流量+500分钟语音',
      chargeStandard: '0.29元/MB',
      limitCondition: '四川省范围内使用，合约期内不可销户',
      otherEquity: '生日特权、流量结转、优先客服',
      smsContent: '尊敬的用户，您的套餐已办理成功',
      sysNoteNow: '恭喜您成功办理动感地带青春卡99元G套餐，月费99元，含20G流量和500分钟语音，感谢您的支持！',
      sysNoteNext: '您的动感地带青春卡99元G套餐已生效，月费99元，生效当月起享受套餐权益。',
      sysNoteCancle: '您好，您的动感地带青春卡99元G套餐已退订，如有疑问请致电10086。',
      sysNoteErke: '尊敬的客户，您正在办理动感地带青春卡99元G套餐，月费99元，是否确认办理？',
      chargeType: 'monthly',
      monthlyFee: '99.00',
      feeSubject: '001',
      taxRate: '6',
      minConsumeType: 'none',
      flowType: 'general',
      flowAmount: '20',
      flowUnit: 'GB',
      flowOvercharge: '0.29元/MB',
      flowCarryover: 'yes',
      voiceType: 'local',
      voiceAmount: '500',
      voiceOvercharge: '0.15元/分钟',
      smsAmount: '100',
      smsOvercharge: '0.1元/条',
    },
  },
  {
    id: 'P002',
    code: 'WO20250115002',
    name: '动感地带青春卡129元G',
    template: 'personMainPrc',
    desc: '月费129元 | 30G流量 | 800分钟语音 | 合约36个月',
    status: 'submitted',
    auditStatus: 'pass',
    data: {
      workOrderId: 'WO20250115002',
      prodPrcName: '动感地带青春卡129元G',
      effRuleId: '1001',
      expRuleId: '1023',
      effDate: '2026-07-01',
      expDate: '2099-12-31',
      prodId: 'APAP00002',
      prodPrcId: 'ACAG00002',
      chnClassLimit: 'A7',
      groupId: '10001',
      groupIdMessage: '1,2,3,4,5',
      prcMonthFee: '129元/月',
      containResource: '30G流量+800分钟语音',
      chargeStandard: '0.29元/MB',
      limitCondition: '四川省范围内使用，合约期内不可销户',
      otherEquity: '生日特权、流量结转、视频会员',
      smsContent: '尊敬的用户，您的套餐已办理成功',
      sysNoteNow: '恭喜您成功办理动感地带青春卡129元G套餐，月费129元，含30G流量和800分钟语音，感谢您的支持！',
      sysNoteNext: '您的动感地带青春卡129元G套餐已生效，月费129元，生效当月起享受套餐权益。',
      sysNoteCancle: '您好，您的动感地带青春卡129元G套餐已退订，如有疑问请致电10086。',
      sysNoteErke: '尊敬的客户，您正在办理动感地带青春卡129元G套餐，月费129元，是否确认办理？',
      chargeType: 'monthly',
      monthlyFee: '129.00',
      feeSubject: '001',
      taxRate: '6',
      minConsumeType: 'none',
      flowType: 'general',
      flowAmount: '30',
      flowUnit: 'GB',
      flowOvercharge: '0.29元/MB',
      flowCarryover: 'yes',
      voiceType: 'local',
      voiceAmount: '800',
      voiceOvercharge: '0.15元/分钟',
      smsAmount: '200',
      smsOvercharge: '0.1元/条',
    },
  },
]

export const scene2Products = [
  {
    id: 'P101',
    name: '畅享校园卡39元套餐',
    desc: '月费39元 | 10G流量 | 100分钟语音 | 仅限大学生',
    status: 'draft',
    auditStatus: 'pending',
    data: {
      workOrderId: 'WO20260624001',
      prodPrcName: '畅享校园卡39元套餐',
      effRuleId: '1001',
      expRuleId: '1023',
      effDate: '2026-09-01',
      expDate: '2099-12-31',
      prodId: 'APAP00101',
      prodPrcId: 'ACAG00101',
      chnClassLimit: 'A1',
      groupId: '10001',
      prcMonthFee: '39元/月',
      containResource: '10G流量+100分钟语音',
      chargeStandard: '0.29元/MB',
      limitCondition: '仅限四川在校大学生办理，需学生证认证',
      otherEquity: '生日特权、流量结转',
      smsContent: '尊敬的用户，您的套餐已办理成功',
      sysNoteNow: '恭喜您成功办理畅享校园卡39元套餐，月费39元，含10G流量和100分钟语音，感谢您的支持！',
      sysNoteNext: '您的畅享校园卡39元套餐已生效，月费39元，生效当月起享受套餐权益。',
      sysNoteCancle: '您好，您的畅享校园卡39元套餐已退订，如有疑问请致电10086。',
      sysNoteErke: '尊敬的客户，您正在办理畅享校园卡39元套餐，月费39元，是否确认办理？',
      chargeType: 'monthly',
      monthlyFee: '39.00',
      feeSubject: '001',
      taxRate: '6',
      minConsumeType: 'none',
      flowType: 'general',
      flowAmount: '10',
      flowUnit: 'GB',
      flowOvercharge: '0.29元/MB',
      flowCarryover: 'yes',
      voiceType: 'local',
      voiceAmount: '100',
      voiceOvercharge: '0.15元/分钟',
      smsAmount: '20',
      smsOvercharge: '0.1元/条',
    },
  },
  {
    id: 'P102',
    name: '畅享校园卡59元套餐',
    desc: '月费59元 | 20G流量 | 100分钟语音 | 含宽带',
    status: 'draft',
    auditStatus: 'pending',
    data: {
      workOrderId: 'WO20260624002',
      prodPrcName: '畅享校园卡59元套餐',
      effRuleId: '1001',
      expRuleId: '1023',
      effDate: '2026-09-01',
      expDate: '2099-12-31',
      prodId: 'APAP00102',
      prodPrcId: 'ACAG00102',
      chnClassLimit: 'A1',
      groupId: '10001',
      prcMonthFee: '59元/月',
      containResource: '20G流量+100分钟语音+宽带使用权',
      chargeStandard: '0.29元/MB',
      limitCondition: '仅限四川在校大学生办理，含宽带安装服务',
      otherEquity: '生日特权、流量结转、视频会员',
      smsContent: '尊敬的用户，您的套餐已办理成功',
      sysNoteNow: '恭喜您成功办理畅享校园卡59元套餐，月费59元，含20G流量和100分钟语音，含宽带使用权，感谢您的支持！',
      sysNoteNext: '您的畅享校园卡59元套餐已生效，月费59元，生效当月起享受套餐权益。',
      sysNoteCancle: '您好，您的畅享校园卡59元套餐已退订，如有疑问请致电10086。',
      sysNoteErke: '尊敬的客户，您正在办理畅享校园卡59元套餐，月费59元，是否确认办理？',
      chargeType: 'monthly',
      monthlyFee: '59.00',
      feeSubject: '001',
      taxRate: '6',
      minConsumeType: 'none',
      flowType: 'general',
      flowAmount: '20',
      flowUnit: 'GB',
      flowOvercharge: '0.29元/MB',
      flowCarryover: 'yes',
      voiceType: 'local',
      voiceAmount: '100',
      voiceOvercharge: '0.15元/分钟',
      smsAmount: '20',
      smsOvercharge: '0.1元/条',
    },
  },
  {
    id: 'P103',
    name: '畅享校园卡79元套餐',
    desc: '月费79元 | 30G流量 | 300分钟语音 | 含视频会员',
    status: 'draft',
    auditStatus: 'pending',
    data: {
      workOrderId: 'WO20260624003',
      prodPrcName: '畅享校园卡79元套餐',
      effRuleId: '1001',
      expRuleId: '1023',
      effDate: '2026-09-01',
      expDate: '2099-12-31',
      prodId: 'APAP00103',
      prodPrcId: 'ACAG00103',
      chnClassLimit: 'A1',
      groupId: '10001',
      prcMonthFee: '79元/月',
      containResource: '30G流量+300分钟语音+视频会员',
      chargeStandard: '0.29元/MB',
      limitCondition: '仅限四川在校大学生办理，含视频会员月卡',
      otherEquity: '生日特权、流量结转、视频会员',
      smsContent: '尊敬的用户，您的套餐已办理成功',
      sysNoteNow: '恭喜您成功办理畅享校园卡79元套餐，月费79元，含30G流量和300分钟语音，含视频会员权益，感谢您的支持！',
      sysNoteNext: '您的畅享校园卡79元套餐已生效，月费79元，生效当月起享受套餐权益。',
      sysNoteCancle: '您好，您的畅享校园卡79元套餐已退订，如有疑问请致电10086。',
      sysNoteErke: '尊敬的客户，您正在办理畅享校园卡79元套餐，月费79元，是否确认办理？',
      chargeType: 'monthly',
      monthlyFee: '79.00',
      feeSubject: '001',
      taxRate: '6',
      minConsumeType: 'none',
      flowType: 'general',
      flowAmount: '30',
      flowUnit: 'GB',
      flowOvercharge: '0.29元/MB',
      flowCarryover: 'yes',
      voiceType: 'local',
      voiceAmount: '300',
      voiceOvercharge: '0.15元/分钟',
      smsAmount: '50',
      smsOvercharge: '0.1元/条',
    },
  },
]

export const SKILL_CONFIG = {
  query: { icon: 'fa-magnifying-glass', label: '智查·历史复用', placeholder: '请输入商品名称、编码或关键词...' },
  file: { icon: 'fa-file-import', label: '智读·文件配置', placeholder: '或在此输入方案描述...' },
  chat: { icon: 'fa-comments', label: '智聊·对话配置', placeholder: '请输入您的配置需求，如：我要一个大学生套餐' },
}

export function createEmptyFormData() {
  return {
    workOrderId: '',
    prodPrcName: '',
    effRuleId: '1001',
    expRuleId: '1023',
    effDate: '',
    expDate: '2099-12-31',
    prodId: '',
    prodPrcId: '',
    chnClassLimit: 'A7',
    groupId: '10001',
    groupIdMessage: '',
    prcMonthFee: '',
    containResource: '',
    chargeStandard: '',
    limitCondition: '',
    otherEquity: '',
    smsContent: '',
    sysNoteNow: '',
    sysNoteNext: '',
    sysNoteCancle: '',
    sysNoteErke: '',
    chargeType: 'monthly',
    monthlyFee: '',
    feeSubject: '001',
    taxRate: '6',
    discountCondition: '',
    discountType: 'cash',
    discountAmount: '',
    minConsumeType: 'none',
    minConsumeAmount: '',
    flowType: 'general',
    flowAmount: '',
    flowUnit: 'GB',
    flowOvercharge: '',
    flowCarryover: 'yes',
    voiceType: 'local',
    voiceAmount: '',
    voiceOvercharge: '',
    smsAmount: '',
    smsOvercharge: '',
  }
}

export const CAMPUS_PRODUCT_DATA = () => ({
  ...createEmptyFormData(),
  workOrderId: 'WO' + Date.now(),
  prodPrcName: '5G-A校园卡49元G（大学生专享）',
  effRuleId: '1001',
  expRuleId: '1023',
  effDate: new Date().toISOString().split('T')[0],
  expDate: '2099-12-31',
  prodId: 'APAP00201',
  prodPrcId: 'ACAG00201',
  chnClassLimit: 'A7',
  groupId: '10001',
  prcMonthFee: '49元/月',
  containResource: '15G流量+200分钟语音',
  chargeStandard: '0.29元/MB',
  limitCondition: '仅限四川在校大学生办理，合约期内不可销户',
  otherEquity: '生日特权、流量结转',
  smsContent: '尊敬的用户，您的套餐已办理成功',
  sysNoteNow: '恭喜您成功办理5G-A校园卡49元G套餐，月费49元，含15G流量和200分钟语音，感谢您的支持！',
  sysNoteNext: '您的5G-A校园卡49元G套餐已生效，月费49元，生效当月起享受套餐权益。',
  sysNoteCancle: '您好，您的5G-A校园卡49元G套餐已退订，合约期内退订需支付违约金。',
  sysNoteErke: '尊敬的客户，您正在办理5G-A校园卡49元G套餐，月费49元，是否确认办理？',
  chargeType: 'monthly',
  monthlyFee: '49.00',
  feeSubject: '001',
  taxRate: '6',
  minConsumeType: 'none',
  flowType: 'general',
  flowAmount: '15',
  flowUnit: 'GB',
  flowOvercharge: '0.29元/MB',
  flowCarryover: 'yes',
  voiceType: 'local',
  voiceAmount: '200',
  voiceOvercharge: '0.15元/分钟',
  smsAmount: '20',
  smsOvercharge: '0.1元/条',
})

/**
 * 将本体草稿映射为旧版产品表单字段（兼容展示）
 */
export function draftToFormData(draft = {}) {
  const data = createEmptyFormData()
  const fee = draft.fixedFeeAmount != null ? draft.fixedFeeAmount : draft.monthlyFee
  const name = draft.offerName || draft.offeringName || ''
  data.prodPrcName = name
  data.workOrderId = draft.workOrderId || data.workOrderId
  data.monthlyFee = fee != null ? String(fee) : ''
  data.prcMonthFee = fee != null ? `${fee}元/月` : ''
  data.containResource = [draft.includeData, draft.includeVoice, draft.includeBroadband]
    .filter(Boolean)
    .join('+')
  data.flowAmount = String(draft.includeData || '').replace(/[^\d.]/g, '') || data.flowAmount
  data.voiceAmount = String(draft.includeVoice || '').replace(/[^\d.]/g, '') || data.voiceAmount
  data.offerName = name
  data.offeringName = name
  data.offeringType = draft.offeringType || ''
  data.bizScenario = draft.bizScenario || ''
  data.targetUser = draft.targetUser || ''
  data.channelScope = draft.channelScope || ''
  data.regionScope = draft.regionScope || ''
  data.messageRootKey = draft.messageRootKey || ''
  data.categoryCode = draft.categoryCode || ''
  data.categoryName = draft.categoryName || ''
  data.productLine = draft.productLine || ''
  data.fixedFeeAmount = fee != null ? fee : ''
  data.includeVoice = draft.includeVoice || ''
  data.includeData = draft.includeData || ''
  data.includeBroadband = draft.includeBroadband || ''
  data.mutexGroup = draft.mutexGroup || ''
  data.dependOn = draft.dependOn || ''
  data.hasContract = draft.hasContract || '0'
  data.contractMonths = draft.contractMonths || ''
  data.discountPercent = draft.discountPercent || ''
  data.repeatable = draft.repeatable || 'false'
  data.basedOnTemplate = draft.basedOnTemplate || ''
  data.bindExistingMainPkg = draft.bindExistingMainPkg || ''
  data.oneTimeFee = draft.oneTimeFee != null ? draft.oneTimeFee : 0
  data.fillSources = draft.fillSources
    ? JSON.stringify(draft.fillSources, null, 2)
    : ''
  return data
}

/**
 * 本体 ConfigScheme 表单 schema（智聊画布，v2.2）
 */
export function createOfferingFormSchema(draft = {}) {
  const d = { ...draft }
  const fee = d.fixedFeeAmount != null ? d.fixedFeeAmount : d.monthlyFee
  const name = d.offerName || d.offeringName || ''
  const fill = d.fillSources || {}
  const withSrc = (field) => ({
    ...field,
    fillSource: fill[field.fieldCode] || '',
  })
  return {
    formName: '配置方案草稿（本体 v2.2）',
    formCode: 'offering_config',
    fields: [
      withSrc({ fieldCode: 'offerName', fieldName: '资费名称', fieldType: 'input', required: true, value: name }),
      withSrc({ fieldCode: 'offeringName', fieldName: '资费名称(兼容)', fieldType: 'input', required: false, value: name }),
      withSrc({
        fieldCode: 'categoryCode', fieldName: '产品品类', fieldType: 'select', required: true,
        value: d.categoryCode || d.messageRootKey || 'personMainPrc',
        options: [
          { label: '个人主资费', value: 'personMainPrc' },
          { label: '宽带主资费', value: 'broadBandMainPrc' },
          { label: '个人附加资费', value: 'personAddPrc' },
          { label: '宽带加速包', value: 'broadBandOptSpeedPrc' },
          { label: '家庭基础套餐', value: 'familyBasePrc' },
          { label: '家庭附加业务', value: 'familyAddPrc' },
        ],
      }),
      withSrc({ fieldCode: 'messageRootKey', fieldName: '报文根键', fieldType: 'input', required: true, value: d.messageRootKey || d.categoryCode || '' }),
      withSrc({
        fieldCode: 'bizScenario', fieldName: '业务场景', fieldType: 'select', required: false, value: d.bizScenario || '',
        options: [
          { label: '大众-个人主资费', value: '大众-个人主资费' },
          { label: '5G个人主套餐', value: '5G个人主套餐' },
          { label: '校园-个人附加', value: '校园-个人附加' },
          { label: '校园体验', value: '校园体验' },
          { label: '家庭-基础套餐', value: '家庭-基础套餐' },
          { label: '家庭融合', value: '家庭融合' },
          { label: '家庭-宽带主资费', value: '家庭-宽带主资费' },
        ],
      }),
      withSrc({
        fieldCode: 'targetUser', fieldName: '目标用户', fieldType: 'select', required: false, value: d.targetUser || '',
        options: [
          { label: '家庭', value: '家庭' },
          { label: '校园', value: '校园' },
          { label: '个人', value: '个人' },
          { label: '政企', value: '政企' },
        ],
      }),
      withSrc({
        fieldCode: 'channelScope', fieldName: '销售渠道', fieldType: 'select', required: true, value: d.channelScope || '',
        options: [
          { label: '营业前台+电渠等(A7)', value: 'A7' },
          { label: '全渠道', value: '全渠道' },
          { label: '仅电渠', value: '仅电渠' },
          { label: '电渠+厅店', value: '电渠+厅店' },
          { label: '内部验证', value: '内部验证' },
        ],
      }),
      withSrc({ fieldCode: 'regionScope', fieldName: '发布地市', fieldType: 'input', required: false, value: d.regionScope || '' }),
      withSrc({ fieldCode: 'fixedFeeAmount', fieldName: '固费金额(元)', fieldType: 'number', required: true, value: fee }),
      withSrc({ fieldCode: 'monthlyFee', fieldName: '月费(兼容)', fieldType: 'number', required: false, value: fee }),
      withSrc({ fieldCode: 'oneTimeFee', fieldName: '一次性费用', fieldType: 'number', required: false, value: d.oneTimeFee ?? 0 }),
      withSrc({ fieldCode: 'includeVoice', fieldName: '包含语音', fieldType: 'input', required: false, value: d.includeVoice || '' }),
      withSrc({ fieldCode: 'includeData', fieldName: '包含流量', fieldType: 'input', required: false, value: d.includeData || '' }),
      withSrc({ fieldCode: 'includeBroadband', fieldName: '包含宽带', fieldType: 'input', required: false, value: d.includeBroadband || '' }),
      withSrc({ fieldCode: 'mutexGroup', fieldName: '互斥组', fieldType: 'input', required: false, value: d.mutexGroup || 'MAIN_PKG' }),
      withSrc({ fieldCode: 'dependOn', fieldName: '依赖主资费', fieldType: 'input', required: false, value: d.dependOn || '' }),
      withSrc({ fieldCode: 'workOrderId', fieldName: '需求工单号', fieldType: 'input', required: false, value: d.workOrderId || '' }),
      withSrc({
        fieldCode: 'offeringType', fieldName: '主附类型(兼容)', fieldType: 'select', required: false, value: d.offeringType || 'main_pkg',
        options: [
          { label: '主套餐', value: 'main_pkg' },
          { label: '附加包', value: 'addon' },
          { label: '融合套餐', value: 'fusion' },
          { label: '促销商品', value: 'promo' },
        ],
      }),
      withSrc({
        fieldCode: 'hasContract', fieldName: '是否有合约', fieldType: 'select', required: false, value: d.hasContract || '0',
        options: [
          { label: '无合约', value: '0' },
          { label: '有合约', value: '1' },
        ],
      }),
      withSrc({ fieldCode: 'basedOnTemplate', fieldName: '基于模板', fieldType: 'input', required: false, value: d.basedOnTemplate || '' }),
      withSrc({
        fieldCode: 'bindExistingMainPkg',
        fieldName: '绑定在架主套餐',
        fieldType: 'input',
        required: false,
        value: d.bindExistingMainPkg || '',
        placeholder: '如 OF-HF-128（演示互斥）',
      }),
    ],
  }
}

/**
 * 生成 DynamicForm 兼容的产品配置表单 schema
 * 将 demo 的 4-tab ConfigForm 扁平化为单表单
 * @param {Object} formData - 初始表单数据（可选）
 * @returns {Object} DynamicForm schema
 */
export function createProductFormSchema(formData = {}) {
  const data = { ...createEmptyFormData(), ...formData }
  return {
    formName: '产品配置',
    formCode: 'productConfig',
    fields: [
      { fieldCode: 'workOrderId', fieldName: '工单编号', fieldType: 'input', required: false, value: data.workOrderId, placeholder: 'AI推荐生成' },
      { fieldCode: 'prodPrcName', fieldName: '资费名称', fieldType: 'input', required: true, value: data.prodPrcName, placeholder: '请输入资费名称' },
      {
        fieldCode: 'effRuleId', fieldName: '订购生效方式', fieldType: 'select', required: true, value: data.effRuleId,
        options: [
          { label: '立即生效', value: '1001' },
          { label: '次月生效', value: '1002' },
          { label: '预约生效', value: '1003' },
        ],
      },
      {
        fieldCode: 'expRuleId', fieldName: '退订生效方式', fieldType: 'select', required: false, value: data.expRuleId,
        options: [
          { label: '立即失效', value: '1023' },
          { label: '次月失效', value: '1024' },
        ],
      },
      { fieldCode: 'effDate', fieldName: '销售开始日期', fieldType: 'date', required: false, value: data.effDate },
      { fieldCode: 'expDate', fieldName: '销售终止日期', fieldType: 'date', required: false, value: data.expDate },
      { fieldCode: 'prodId', fieldName: '产品代码', fieldType: 'input', required: false, value: data.prodId, placeholder: 'AI推荐生成' },
      { fieldCode: 'prodPrcId', fieldName: '资费代码', fieldType: 'input', required: false, value: data.prodPrcId, placeholder: 'AI推荐生成' },
      {
        fieldCode: 'chnClassLimit', fieldName: '发布渠道', fieldType: 'select', required: false, value: data.chnClassLimit,
        options: [
          { label: '全渠道', value: 'A7' },
          { label: '线下营业厅', value: 'A1' },
          { label: '线上渠道', value: 'A2' },
          { label: '代理商', value: 'A3' },
        ],
      },
      {
        fieldCode: 'groupId', fieldName: '发布地市', fieldType: 'select', required: false, value: data.groupId,
        options: [
          { label: '四川', value: '10001' },
          { label: '成都', value: '10002' },
          { label: '绵阳', value: '10003' },
          { label: '德阳', value: '10004' },
          { label: '南充', value: '10005' },
        ],
      },
      { fieldCode: 'groupIdMessage', fieldName: '地市明细', fieldType: 'input', required: false, value: data.groupIdMessage, placeholder: '多个地市用逗号分隔' },
      { fieldCode: 'prcMonthFee', fieldName: '套餐月费', fieldType: 'input', required: false, value: data.prcMonthFee, placeholder: '如：99元/月' },
      { fieldCode: 'containResource', fieldName: '包含资源', fieldType: 'input', required: false, value: data.containResource, placeholder: '如：20G流量+500分钟语音' },
      { fieldCode: 'chargeStandard', fieldName: '超套收费标准', fieldType: 'input', required: false, value: data.chargeStandard, placeholder: '如：0.29元/MB' },
      { fieldCode: 'limitCondition', fieldName: '限定条件', fieldType: 'textarea', required: false, value: data.limitCondition },
      { fieldCode: 'otherEquity', fieldName: '其他权益', fieldType: 'textarea', required: false, value: data.otherEquity },
      { fieldCode: 'smsContent', fieldName: '短信内容', fieldType: 'textarea', required: false, value: data.smsContent },
      { fieldCode: 'sysNoteNow', fieldName: '成功短信（立即）', fieldType: 'textarea', required: false, value: data.sysNoteNow },
      { fieldCode: 'sysNoteNext', fieldName: '成功短信（预约）', fieldType: 'textarea', required: false, value: data.sysNoteNext },
      { fieldCode: 'sysNoteCancle', fieldName: '退订短信', fieldType: 'textarea', required: false, value: data.sysNoteCancle },
      { fieldCode: 'sysNoteErke', fieldName: '前台二确短信', fieldType: 'textarea', required: false, value: data.sysNoteErke },
      {
        fieldCode: 'chargeType', fieldName: '收费方式', fieldType: 'select', required: false, value: data.chargeType,
        options: [
          { label: '月付', value: 'monthly' },
          { label: '季付', value: 'quarterly' },
          { label: '年付', value: 'yearly' },
        ],
      },
      { fieldCode: 'monthlyFee', fieldName: '套餐固定费', fieldType: 'number', required: true, value: data.monthlyFee, placeholder: '0.00' },
      {
        fieldCode: 'feeSubject', fieldName: '收费科目', fieldType: 'select', required: false, value: data.feeSubject,
        options: [
          { label: '通讯费', value: '001' },
          { label: '增值业务费', value: '002' },
          { label: '代收费', value: '003' },
        ],
      },
      {
        fieldCode: 'taxRate', fieldName: '税率', fieldType: 'select', required: false, value: data.taxRate,
        options: [
          { label: '6%', value: '6' },
          { label: '9%', value: '9' },
          { label: '13%', value: '13' },
        ],
      },
      { fieldCode: 'discountCondition', fieldName: '优惠条件', fieldType: 'input', required: false, value: data.discountCondition },
      {
        fieldCode: 'discountType', fieldName: '优惠类型', fieldType: 'select', required: false, value: data.discountType,
        options: [
          { label: '返费', value: 'cash' },
          { label: '打折', value: 'discount' },
          { label: '赠送', value: 'free' },
        ],
      },
      { fieldCode: 'discountAmount', fieldName: '优惠费用', fieldType: 'number', required: false, value: data.discountAmount },
      {
        fieldCode: 'minConsumeType', fieldName: '保底方式', fieldType: 'select', required: false, value: data.minConsumeType,
        options: [
          { label: '无保底', value: 'none' },
          { label: '月保底', value: 'monthly' },
          { label: '总额保底', value: 'total' },
        ],
      },
      { fieldCode: 'minConsumeAmount', fieldName: '保底费用', fieldType: 'number', required: false, value: data.minConsumeAmount },
      {
        fieldCode: 'flowType', fieldName: '流量类型', fieldType: 'select', required: false, value: data.flowType,
        options: [
          { label: '通用流量', value: 'general' },
          { label: '定向流量', value: '定向' },
          { label: '专属流量', value: '专属' },
        ],
      },
      { fieldCode: 'flowAmount', fieldName: '流量资源量', fieldType: 'input', required: true, value: data.flowAmount, placeholder: '如：20' },
      {
        fieldCode: 'flowUnit', fieldName: '流量单位', fieldType: 'select', required: false, value: data.flowUnit,
        options: [
          { label: 'GB', value: 'GB' },
          { label: 'MB', value: 'MB' },
        ],
      },
      { fieldCode: 'flowOvercharge', fieldName: '流量套外计费', fieldType: 'input', required: false, value: data.flowOvercharge, placeholder: '如：0.29元/MB' },
      {
        fieldCode: 'flowCarryover', fieldName: '流量是否结转次月', fieldType: 'select', required: false, value: data.flowCarryover,
        options: [
          { label: '是', value: 'yes' },
          { label: '否', value: 'no' },
        ],
      },
      {
        fieldCode: 'voiceType', fieldName: '语音资源类型', fieldType: 'select', required: false, value: data.voiceType,
        options: [
          { label: '本地语音', value: 'local' },
          { label: '长途语音', value: 'longdistance' },
        ],
      },
      { fieldCode: 'voiceAmount', fieldName: '语音资源量', fieldType: 'input', required: false, value: data.voiceAmount, placeholder: '如：500' },
      { fieldCode: 'voiceOvercharge', fieldName: '语音套外计费', fieldType: 'input', required: false, value: data.voiceOvercharge, placeholder: '如：0.15元/分钟' },
      { fieldCode: 'smsAmount', fieldName: '短信资源量', fieldType: 'input', required: true, value: data.smsAmount, placeholder: '如：100' },
      { fieldCode: 'smsOvercharge', fieldName: '短信套外计费', fieldType: 'input', required: false, value: data.smsOvercharge, placeholder: '如：0.1元/条' },
    ],
  }
}
