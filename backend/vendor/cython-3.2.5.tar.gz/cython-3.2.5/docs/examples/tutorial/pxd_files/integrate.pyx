from cmath cimport sin
